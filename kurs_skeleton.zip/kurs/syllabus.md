# Kursfahrplan (Syllabus)

| Nr. | Lektion | Lernziele | Material |
|---:|---|---|---|
| 1 | GL1_intro – Ankommen & Überblick | Kursüberblick, Erwartungen, Geräte kennenlernen | `lessons/01_intro/` |
| 2 | GL2_dateien – Dateien & Ordner | Dateien anlegen, umbenennen, Ordnerstruktur | `lessons/02_dateien/` |

> Pflege hier die Reihenfolge und groben Lernziele pro Lektion.
