Allgemeine, kursweite Grafiken/Logos hier ablegen.
