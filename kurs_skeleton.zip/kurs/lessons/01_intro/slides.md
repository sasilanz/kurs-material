---
marp: true
theme: default
paginate: true
size: 16:9
title: "Intro & Ankommen"
description: "IT‑Kurs – Intro & Ankommen"
class: lead
---

# Intro & Ankommen

_IT‑Kurs Dietikon_

---

## Heute

- Ziele
- Kurzinput
- Übung
- Rückblick

---

## Übung

1. …
2. …

---

## Rückblick

- Was war neu?
- Was war schwierig?
- Hausaufgabe (optional)
