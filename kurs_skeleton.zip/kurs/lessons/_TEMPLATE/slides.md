---
marp: true
theme: default
paginate: true
size: 16:9
title: "{{TITLE}}"
description: "IT‑Kurs – {{TITLE}}"
class: lead
---

# {{TITLE}}

_IT‑Kurs Dietikon_

---

## Heute

- Ziele
- Kurzinput
- Übung
- Rückblick

---

## Übung

1. …
2. …

---

## Rückblick

- Was war neu?
- Was war schwierig?
- Hausaufgabe (optional)
