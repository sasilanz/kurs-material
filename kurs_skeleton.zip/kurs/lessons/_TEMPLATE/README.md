---
title: "{TITLE}"
date: 2025-08-21
tags: [{TAGS}]
duration: 90 # Minuten
# Hinweise:
# - 'title' und 'tags' werden von new-lesson.sh befüllt
---

# {TITLE}

## Ziele heute
- …

## Ablauf
1. Einstieg (5’)
2. Input (30’)
3. Übung (40’)
4. Rückblick (15’)

## Notizen (für dich)
- Raum/Setup: …
- Häppchen/Story: …

## Handout (für Teilnehmende)
- Stichpunkte …
